package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteFeign;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = consultar(usuario);
		
		// Solo creamos el carrito si no existe otro para ese usuario
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		
		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		// Crear el pedido a traves de la peticion con feign
		Pedido pedido = clienteFeign.crear(id, cantidad);
		
		// Buscar el carrito de ese usuario
		Carrito carrito = consultar(usuario);
		
		// y agregar el pedido al contenido
		carrito.getContenido().add(pedido);
		
		// Modificar el importe del carrito (importe_anterior + importe_pedido)
		double importePedido = pedido.getProducto().getPrecio() * pedido.getCantidad();
		carrito.setImporte(carrito.getImporte() + importePedido);
		
		// Lo actualizamos en la BBDD y se retorna
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		// Consultar el carrito del usuario 
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		// Solo borro el primer pedido que encuentre con ese id de producto
		Pedido encontrado =  contenido
								.stream()
								.filter(ped -> ped.getProducto().getID() == id)
								.findFirst()
								.get();
		contenido.remove(encontrado);
		
		// Modificar el importe del carrito
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		
		// Lo actualizamos en la BBDD y se retorna
		return dao.save(carrito);
	}

}






