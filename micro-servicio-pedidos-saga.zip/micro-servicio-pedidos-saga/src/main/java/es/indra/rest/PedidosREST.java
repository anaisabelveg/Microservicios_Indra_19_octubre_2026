package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;

@RestController
public class PedidosREST {
	
	@Autowired
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/4/cantidad/50
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// http://localhost:8002/saga/descripcion/Mesa/precio/150/proveedor/Maria
	// http://localhost:8002/saga/descripcion/Silla/precio/90/proveedor/Pepe
	@GetMapping("/saga/descripcion/{descripcion}/precio/{precio}/proveedor/{nombre}")
	public String pruebaSaga(@PathVariable String descripcion, @PathVariable double precio, @PathVariable String nombre) {
		return bs.pruebaTransaccion(descripcion, precio, nombre);
	}

}
