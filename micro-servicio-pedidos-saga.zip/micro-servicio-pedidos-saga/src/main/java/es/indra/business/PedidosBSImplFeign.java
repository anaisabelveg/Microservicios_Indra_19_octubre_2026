package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.clients.ProveedoresClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
@Primary  // Damos preferencia para que inyecte este bean
public class PedidosBSImplFeign implements IPedidosBS{
	
	@Autowired
	private ProductosClienteFeign productosClienteFeign;
	
	@Autowired
	private ProveedoresClienteFeign proveedoresClienteFeign;

	
	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = productosClienteFeign.buscar(id);
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

	@Override
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor) {
		String mensaje = "";
		Producto producto = null;
		
		try {
			// Dar de alta el producto
			producto = productosClienteFeign.nuevo(descripcion, precio);
			
			// Dar de alta el proveedor
			mensaje = proveedoresClienteFeign.altaProveedor(nombreProveedor);
			
		} catch (Exception e) {
			// Deshacer la transaccion, llamando a la operacion compensatoria 
			// (eliminar el producto creado)
			if (producto != null) {
				String msg = productosClienteFeign.eliminar(producto.getID());
				System.out.println("****************************** " + msg);
				mensaje = "Rollback de la transaccion " + msg;
			}
			
		}
		
		
		return mensaje;
	}

}
