package es.indra.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // getter, setter, toString, equals, hashcode
@NoArgsConstructor   // Constructor por defecto
@AllArgsConstructor  // Constructor completo
public class Producto {
	
	private Long ID;
	private String descripcion;
	private double precio;

}
