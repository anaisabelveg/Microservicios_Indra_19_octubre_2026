-- los pw estan encriptados y son "12345"
INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$U57h9vDDpWVaHja4djCmguVjvPD9AoYbborXzslRjJLqv5lEQooRu', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$16CJYzKbqBAV6QVH261eNOFHSN5AY4Xqr1eWc4x4goVczrS7um3Ui', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles(nombre) values ('ROLE_USER');
INSERT INTO roles(nombre) values ('ROLE_ADMIN');

INSERT INTO usuarios_roles(usuario_id, role_id) values (1,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,2);