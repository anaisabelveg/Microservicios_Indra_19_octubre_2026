package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
// @ComponentScan escanea todas las clases desde el paquete es.indra y genera los beans
@EnableEurekaClient
public class MicroServicioProductosApplication {

	public static void main(String[] args) {
		// Levantar el contexto de String
		// Crear el contenedor y los beans de Spring
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

}
