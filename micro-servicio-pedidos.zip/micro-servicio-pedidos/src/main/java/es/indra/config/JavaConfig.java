package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class JavaConfig {
	
	@Bean   // convierte el objeto Java en un bean de Spring
	// El nombre del metodo es el id o nombre del bean
	public RestTemplate restTemplate() {
		return new RestTemplate();   // retorna un objeto Java
	}

}
